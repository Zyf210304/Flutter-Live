import 'package:flutter/material.dart';
import 'package:fijkplayer/fijkplayer.dart';

class MediaPage extends StatefulWidget {
  const MediaPage({super.key});

  @override
  State<MediaPage> createState() => _MediaPageState();
}

class _MediaPageState extends State<MediaPage> {
  final FijkPlayer player = FijkPlayer();

  @override
  void initState() {
    super.initState();
    _initMedia();
  }

  @override
  void dispose() {
    super.dispose();
    player.release(); //注意：销毁FijkPlayer
  }

  //初始化视频
  _initMedia() {
    player.setDataSource("http://192.168.0.6:8000/live/itying.flv",
        autoPlay: true);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text("流媒体直播/播放视频"),
        ),
        body: ListView(
          children: [
            SizedBox(
              height: 300,
              child: FijkView(
                player: player,
              ),
            )
          ],
        ));
  }
}
